export const ADD_TO_BASKET = "ADD_TO_BASKET";
export let remove_from_cart = "remove_from_cart";
